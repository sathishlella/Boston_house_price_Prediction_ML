import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


path =r"C:\Users\TOSHIBA-PC\Desktop\bostonhouse.csv"
names=["a","b","c","d","e","f","g","h","i","j","K","l","m","target"]

data=pd.read_csv(path , names=names)
print(data.shape)

data1=data.drop("m",axis =1)#it is used for unwanted coloumn

#data=data1.fillna(0)#it is used for empty data filled with 0
print(data.shape)

print(data.corr())
plt.show()
data.hist()
#plt.show()

X=data.iloc[:, :13] .values
y=data.iloc[ :,13].values
#print(y.shape)

from sklearn.model_selection import train_test_split

X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2898)
#print(X_train.shape)

from sklearn.linear_model import LinearRegression
model=LinearRegression()
model.fit(X_train,y_train)

y_pred=model.predict(X_test)
y_pred1=model.predict([[0.03237,0,2,0,0.458,6.998,45.8,6.0622,3,222,18,394.63,2.94]])
print(y_pred1)#it shows value of land
 
from sklearn.metrics import mean_squared_error
print("rms error:",mean_squared_error(y_test,y_pred))#it says + or - from result

